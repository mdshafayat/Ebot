
function serial_send (data_to_send)
global sr
fprintf(sr,'%s', data_to_send);
end


