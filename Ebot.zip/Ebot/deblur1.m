% function luc1 = deblur1(I)
% function luc3 = deblur1(I)
function luc2 = deblur1(I)

%% Step 1: Read Image
% |deconvlucy| function can handle arrays of any dimension.
% V=0.002;
figure;imshow(I);title('Original Image');

%% Step 2: Simulate a Blur and Noise
PSF = fspecial('gaussian',5,5);
BlurredNoisy = I;

%% Step 3: Restore the Blurred and Noisy Image
% luc1 = deconvlucy(BlurredNoisy,PSF,5);
% figure;imshow(luc1);title('Restored Image, NUMIT = 5');

%% Step 4: Iterate to Explore the Restoration 

luc1_cell = deconvlucy({BlurredNoisy},PSF,5);
luc2_cell = deconvlucy(luc1_cell,PSF);
luc2 = im2uint8(luc2_cell{2});
figure;imshow(luc2);title('Restored Image, NUMIT = 15');

% DAMPAR = im2uint8(3*sqrt(V));
% luc3 = deconvlucy(BlurredNoisy,PSF,15,DAMPAR);
% figure;imshow(luc3);
% title('Restored Image with Damping, NUMIT = 15');