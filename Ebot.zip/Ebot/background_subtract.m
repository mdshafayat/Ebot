
function [re_image h v]=background_subtract(data1, data2)

%data1=background
%data2=with image

imshow(data1)
imshow(data2)

diff_image = imsubtract(data2,data1);
figure
imshow(diff_image)

gray_image = rgb2gray(diff_image);
figure
imshow(gray_image)

binary_image =im2bw(gray_image,0.15);
figure
imshow(binary_image)

binary_image = bwareaopen(binary_image,300);
figure
imshow(binary_image)

if (max(max(binary_image))~=0) || (min(min(binary_image))~=0)    
    labeled_image = bwlabel(binary_image, 8);
    blobMeasurements = regionprops(labeled_image, 'all');
    %area= regionprops(labeled_image, 'area')
    figure
    imshow(data2)
    hold on;
    i=1;
    bb = blobMeasurements(i).BoundingBox
    bc = blobMeasurements(i).Centroid
    rectangle('Position',bb,'EdgeColor','r','LineWidth',2)
    plot(bc(1),bc(2), '-m+')
    a=text(bc(1)+15,bc(2), strcat('X: ', num2str(round(bc(1))), '    Y: ', num2str(round(bc(2)))));
    set(a, 'FontName', 'Arial', 'FontWeight', 'bold', 'FontSize', 12, 'Color', 'yellow');
    %     ara = blobMeasurements(i).Area
    figure
    img=imcrop(data2,bb);
    imshow(img)
    re_image=img;
    h=bb(3);
    v=bb(4);
    hold off;
    
else
    fprintf('nothing found')
    re_image=NaN;
end
