function rec = speechrecognition
% Add assembly
NET.addAssembly('System.Speech');
% Construct engine
rec = System.Speech.Recognition.SpeechRecognitionEngine;
rec.SetInputToDefaultAudioDevice;
rec.LoadGrammar(System.Speech.Recognition.DictationGrammar);
% Define listener callback
addlistener(rec, 'SpeechRecognized', @recognizedFcn);
% Start recognition
rec.RecognizeAsync(System.Speech.Recognition.RecognizeMode.Multiple);
% Callback
function recognizedFcn(obj, e)
% Get text
txt = char(e.Result.Text)
% Split into words
w = regexp(txt, '\s', 'split');
if length(w) > 1
    % Look for the occurrence of the phrase "search for"
    idx = find(strcmp(w(1:end-1), 'search') & ...
        strcmp(w(2:end), 'for'), 1, 'first');
    if ~isempty(idx) && length(w) >= idx+2
        % The words after are the search terms
        searchTerm = sprintf('%s+', w{idx+2:end});
        searchTerm(end) = '';
          % Search on the web
          web(['http://www.google.com/search?q=', searchTerm]);
          fprintf(2, 'search for "%s"\n', strrep(searchTerm, '+', ' '));
      else
          %disp(txt)
      end
  elseif length(w) == 1 && strcmpi(w{1}, 'stop')
      obj.RecognizeAsyncStop;
      obj.delete;
      %disp(txt);
      disp('Stopping Speech Recognition. Thank you for using!');
  else
      %disp(txt);
  end