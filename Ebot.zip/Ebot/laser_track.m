function d= laser_track(data,binfact,threshold)
        
        rgb2gray(data);
        figure(1)
        imshow(rgb2gray(data))
        hold on
        figure(2)
        imshow(data(:,:,1))
        
    % Now to track red objects in real time
    % we have to subtract the red component 
    % from the grayscale image to extract the red components in the image.
    diff_im = imsubtract(data(:,:,1), rgb2gray(data));
    
        figure(3)
        imshow(diff_im)
    %Use a median filter to filter out noise
    diff_im = medfilt2(diff_im, [3 3]);
    
        figure(4)
        imshow(diff_im)
    % Convert the resulting grayscale image into a binary image.
    diff_im = im2bw(diff_im,binfact); %binary factor is decrerased lower value count as one used value=0.16
    
        figure(5)
        imshow(diff_im)
    
    % Remove all those pixels less than threshold size
    diff_im = bwareaopen(diff_im,threshold) %threshold=300 used
    
    if (max(max(diff_im))~=0) || (min(min(diff_im))~=0)
        figure(6)
        imshow(diff_im)
        % Label all the connected components in the image.
        %bw = bwconncomp(diff_im, 8)
        bw=diff_im;

        % Here we do the image blob analysis.
        % We get a set of properties for each labeled region.
        stats = regionprops(bw, 'BoundingBox', 'Centroid');
        % stats = regionprops(diff_im, 'BoundingBox', 'Centroid');
        figure
        % Display the image
        imshow(data)
        hold on

        %This is a loop to bound the red objects in a rectangular box.
        for object = 1:length(stats)
            bb = stats(object).BoundingBox;
            bc = stats(object).Centroid;
            rectangle('Position',bb,'EdgeColor','r','LineWidth',2)
            plot(bc(1),bc(2), '-m+')
            a=text(bc(1)+15,bc(2), strcat('X: ', num2str(round(bc(1))), '    Y: ', num2str(round(bc(2)))));
            set(a, 'FontName', 'Arial', 'FontWeight', 'bold', 'FontSize', 12, 'Color', 'yellow');
        end

        d=round(sqrt((size(diff_im,2)-bc(1))^2+(size(diff_im,1)-bc(2))^2))

    else
        d=NaN;
        fprintf('laser not found')
        
    end
   
    


