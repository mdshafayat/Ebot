% % %%QA MODE

% % %%when ans is not known
% % What are talking about?
% % I dont understand.
% % Seriously?
% % Who would say that?
% % Sorry, cant hear you.
% % Can you repeat that?
% % Sorry, I am not in the mode.
% % You want me to say that?


%%when annoyed
Why dont you leave me alone.
Are you crazy?
Are you kidding?
Are you Insane?
Are you mad?

%when angry
Dont mess with me.
I am gonna kill you.

%when happy
Yahoo
Ha Ha%wav
He He%wav
Hi Hi%wav
Hurray%wav

%when in prank mode
Baziga%wav
Gotcha%wav
Bingo%wav
repeat any thing said by user


%%%ans data base

% % %Love
% % I love you
% % I love Rafi
% % Love, What is it?


% % %% your name
% % My name is walli
% % Walli
% % I am Walli and you?

% %%% my name is X/I am/ any ans after walli asks name
% So, you are X.Nice to meet you
% Nice to meet you X
% Nice name X

%%if silent for long in talk mode 
How can i help you?
may i help you?
Do you want to ask something?
What do you want me do?

% % %%greeting: just repeat
% % Good morning
% % Good noon
% % Good night
% % Good afternoon
% % Good evening
% % Nice to meet you 
% % hello

% %%sing
% few songs random%wav

% % %dance
% % I cant dance
% % I am too old to dance

% % %who Daddy
% % I guess its not you

% % % what can do
% % I can talk
% % I can walk
% % I can do any thing

% % %How are you
% % I am fine.
% % I am tired
% % I feel sick
% % I am bit confused
% % I am alive
% % I am happy

% % %how old are you?
% % I am 18
% % I am at my forties
% % I just born
% % you have no business knowing that!

% % %what are you
% % I am a robot
% % I dont know

% % %do you like me
% % I hate you
% % I dont know
% % who wants to know
% % I like you

%%command mode
talk q/a
recognize object
search and grab
stop
start
move left
move right
move back
move forward
serious%will bring to qa mode


