function [ ] = hear()

%%%Run the .net external program to capture the sound
system('"ConsoleApplication1.exe" &')
beep;
pause(3);

%%%close the sound capturing external program
system('taskkill /f /im ConsoleApplication1.exe');
system('taskkill /f /im cmd.exe');

end

