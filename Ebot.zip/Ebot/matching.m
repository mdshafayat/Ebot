function [flag,xy]=matching(data1,data2)
 %flag- detected or not 1 if not detected
% %% Load reference image, and compute surf features
x_offset = 640;
y_offset = 0;
ref_img = data1;
ref_img_gray = rgb2gray(ref_img);
ref_img_pad = padarray(ref_img, [y_offset 0], 'pre');
ref_pts = detectSURFFeatures(ref_img_gray,'MetricThreshold',500);
[ref_features  ref_validPts] = extractFeatures(ref_img_gray,  ref_pts);

figure; imshow(ref_img);
hold on; 
h1= plot(ref_pts.selectStrongest(50));

%% Compare to video frame
image = data2;
I = rgb2gray(image);

% Detect features
I_pts = detectSURFFeatures(I,'MetricThreshold',500);
[I_features I_validPts] = extractFeatures(I, I_pts);
figure;imshow(image);
hold on; plot(I_pts.selectStrongest(50));

%% Compare card image to video frame
index_pairs = matchFeatures(ref_features, I_features);

ref_matched_pts = ref_validPts(index_pairs(:,1)).Location
I_matched_pts = I_validPts(index_pairs(:,2)).Location

flag=isempty(ref_matched_pts)||isempty(I_matched_pts);

if flag==1
    return;
end
% Draw the lines
ref_offset_matched_pts(:,1) = ref_matched_pts(:,1) + x_offset;
ref_offset_matched_pts(:,2) = ref_matched_pts(:,2) + y_offset;
Pts_match = [ref_offset_matched_pts I_matched_pts ];
I_cat = cat(2, image, ref_img_pad);

hshapeins = vision.ShapeInserter('Shape','Lines', 'BorderColor','Custom',...
                    'CustomBorderColor',[255 0 0]);

Iout = step(hshapeins, I_cat, int32(Pts_match));
figure; imshow(Iout);


%% Define Geometric Transformation Objects
gte = vision.GeometricTransformEstimator; 
gte.Method = 'Random Sample Consensus (RANSAC)';
gte.Transform = 'Nonreflective similarity';
gte.NumRandomSamplingsMethod = 'Desired confidence';
gte.MaximumRandomSamples = 5000;
gte.DesiredConfidence = 99.8;

if isrow(ref_matched_pts)||isrow(I_matched_pts)==1
    return;
end

[tform_matrix inlierIdx] = step(gte, ref_matched_pts, I_matched_pts);

ref_inlier_pts = ref_matched_pts(inlierIdx,:);
I_inlier_pts = I_matched_pts(inlierIdx,:);
xy=max(I_inlier_pts(:,2));

% Draw the lines
ref_offset_inlier_points(:,1) = ref_inlier_pts(:,1) + x_offset;
ref_offset_inlier_points(:,2) = ref_inlier_pts(:,2) + y_offset;
Pts_match = [ref_offset_inlier_points I_inlier_pts];
I_cat = cat(2, image, ref_img_pad);

Iout = step(hshapeins, I_cat, int32(Pts_match));
figure; imshow(Iout);

end
