function varargout = servo_control_rifat(varargin)
% SERVO_CONTROL M-file for servo_control.fig
%      SERVO_CONTROL, by itself, creates a new SERVO_CONTROL or raises the existing
%      singleton*.
%
%      H = SERVO_CONTROL returns the handle to a new SERVO_CONTROL or the handle to
%      the existing singleton*.
%
%      SERVO_CONTROL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SERVO_CONTROL.M with the given input arguments.
%
%      SERVO_CONTROL('Property','Value',...) creates a new SERVO_CONTROL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before servo_control_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to servo_control_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help servo_control

% Last Modified by GUIDE v2.5 03-Aug-2012 05:05:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @servo_control_OpeningFcn, ...
                   'gui_OutputFcn',  @servo_control_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before servo_control is made visible.
function servo_control_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to servo_control (see VARARGIN)

% Choose default command line output for servo_control
handles.output = hObject;
res=str2num(get(handles.res,'String'));
set(handles.ch1_slider,'Min',2000/res,'Max',4000/res,'Value',2000/res,'SliderStep',[res/2000 res/2000]);
set(handles.ch2_slider,'Min',0/res,'Max',39900/res,'Value',0/res,'SliderStep',[res/39900 res/39900]);
set(handles.ch1_tag,'String',num2str((2000/40000)*100));   

handles.Channel=16;
handles.PWM=uint16(repmat(2000,1,handles.Channel));
com=get(handles.port,'String');
str=get(handles.baud,'String');
val=get(handles.baud,'Value');

handles.s=serial(com,'baudrate',str2num(str{val}),'ByteOrder','bigEndian');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes servo_control wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = servo_control_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function port_Callback(hObject, eventdata, handles)
% hObject    handle to port (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.s,'Port',get(hObject,'String'));
% Hints: get(hObject,'String') returns contents of port as text
%        str2double(get(hObject,'String')) returns contents of port as a double


% --- Executes during object creation, after setting all properties.
function port_CreateFcn(hObject, eventdata, handles)
% hObject    handle to port (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function baud_Callback(hObject, eventdata, handles)
% hObject    handle to baud (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
str=get(hObject,'String');
val=get(hObject,'Value');

set(handles.s,'Baud',str2num(str{val}));
% Hints: get(hObject,'String') returns contents of baud as text
%        str2double(get(hObject,'String')) returns contents of baud as a double


% --- Executes during object creation, after setting all properties.
function baud_CreateFcn(hObject, eventdata, handles)
% hObject    handle to baud (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end








% --- Executes on slider movement.
function ch1_slider_Callback(hObject, eventdata, handles)
% hObject    handle to ch1_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

val=get(hObject,'Value');
res=str2num(get(handles.res,'String'));
ch=str2num(get(handles.ch1,'String'))+1;
if ch>16
    msgbox('Select Channel Between 0 and 15');
    return;
end
set(handles.ch1_tag,'String',num2str((val*res)*100/40000));   
pwm=handles.PWM;
pwm(1,ch)=val*res;
fopen(handles.s);
    fprintf(handles.s,'%s','M');
        for i=1:handles.Channel
            fwrite(handles.s,pwm(1,i),'uint16');
        end    
    fprintf(handles.s,'%s',';');
%     pause(.1);
%     fprintf(handles.s,'%s','M');
%         for i=1:handles.Channel
%             fwrite(handles.s,pwm(1,i),'uint16');
%         end    
%     fprintf(handles.s,'%s',';');
    
fclose(handles.s);
handles.PWM=pwm;
guidata(hObject,handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function ch1_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ch1_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function ch2_slider_Callback(hObject, eventdata, handles)
% hObject    handle to ch2_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function ch2_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ch2_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function ch1_Callback(hObject, eventdata, handles)
% hObject    handle to ch1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ch1 as text
%        str2double(get(hObject,'String')) returns contents of ch1 as a double


% --- Executes during object creation, after setting all properties.
function ch1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ch1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ch2_Callback(hObject, eventdata, handles)
% hObject    handle to ch2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ch2 as text
%        str2double(get(hObject,'String')) returns contents of ch2 as a double


% --- Executes during object creation, after setting all properties.
function ch2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ch2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function res_Callback(hObject, eventdata, handles)
% hObject    handle to res (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
res=str2num(get(hObject,'String'));
if res<20
    msgbox('Resolution cannot be less than 20');
    return;
end
set(handles.ch1_slider,'Min',2000/res,'Max',4000/res,'Value',2000/res,'SliderStep',[res/2000 res/2000]);
set(handles.ch2_slider,'Min',0/res,'Max',39900/res,'Value',0/res,'SliderStep',[res/39900 res/39900]);

% Hints: get(hObject,'String') returns contents of res as text
%        str2double(get(hObject,'String')) returns contents of res as a double


% --- Executes during object creation, after setting all properties.
function res_CreateFcn(hObject, eventdata, handles)
% hObject    handle to res (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
