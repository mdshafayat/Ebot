
% function J3 = deblur2(I)
function J2 = deblur2(I)
% function J1 = deblur2(I)

%%deblur the image
%% Step 1: Read Image
% The example reads in an intensity image. The |deconvblind| function can
% handle arrays of any dimension.
% figure;imshow(I);title('Original Image');

PSF = fspecial('gaussian',7,10);
Blurred = I;
figure;imshow(Blurred);title('Blurred Image');

%% Step 3: Restore the Blurred Image Using PSFs of Various Sizes 

%%
% The first restoration, |J1| and |P1|, uses an undersized array, |UNDERPSF|, for
% an initial guess of the PSF. The size of the UNDERPSF array is 4 pixels
% shorter in each dimension than the true PSF. 

UNDERPSF = ones(size(PSF)-4);
% [J1 P1] = deconvblind(Blurred,UNDERPSF);
% figure;imshow(J1);title('Deblurring with Undersized PSF');

%%
% The second restoration, |J2| and |P2|, uses an array of ones, |OVERPSF|, for an
% initial PSF that is 4 pixels longer in each dimension than the true PSF.

OVERPSF = padarray(UNDERPSF,[4 4],'replicate','both');
[J2 P2] = deconvblind(Blurred,OVERPSF);
figure;imshow(J2);title('Deblurring with Oversized PSF');

%%
% The third restoration, |J3| and |P3|, uses an array of ones, |INITPSF|, for an
% initial PSF that is exactly of the same size as the true PSF.

% INITPSF = padarray(UNDERPSF,[2 2],'replicate','both');
% [J3 P3] = deconvblind(Blurred,INITPSF);
% figure;imshow(J3);title('Deblurring with INITPSF');
