clc;
close all;
clear all;
imaqreset
global sr

%for head rotating- a: minimum head rotation angle
%for head down      b: minimum head down angle
%movement           m: movement pitch (will be determined from callibration of distance wrt scale)
%hand movement      h: pitch
%grabbing           g: do grabbing

NET.addAssembly('System.Speech');
Speaker = System.Speech.Synthesis.SpeechSynthesizer;

sr= serial('COM1', 'InputBufferSize', 50000); %COM name according to pc
fopen(sr);
set(sr,'BaudRate',9600);
sr.terminator = 'CR'; 

vid = videoinput('winvideo', 1, 'YUY2_640x480');

% Set the properties of the video object
set(vid, 'FramesPerTrigger', Inf);
set(vid, 'ReturnedColorspace', 'rgb')
vid.FrameGrabInterval = 3;

preview(vid)
pause(10)
start(vid)

data1=NaN;



while(1)
    %%hear what is being said
    hear();
    fid = fopen('savetext.txt', 'r');
    a = fscanf(fid,'%c',inf);
%   a=fgets(fid);
    fclose(fid);

    if strcmp(lower(a),'recognize')
        Speaker.Speak ('first, give me the background');

        while ISNAN(data1)==1
            dataB = getsnapshot(vid); %background only
            figure
            imshow(data1)

            Speaker.Speak ('now, give me the object');
            pause(5)
            data1 = getsnapshot(vid); % image containing object
            [data1 h v]=background_subtract(dataB, data1);
        end

        Speaker.Speak ('what is it?');
        
        %%hear what is being said
        hear();
        pause(5);
        
        fid = fopen('savetext.txt', 'r');
        name = fscanf(fid,'%c',inf);
%       name=fgets(fid);
        fclose(fid);

        ims(data1,name)
    

    elseif strcmp(lower(a),'find')||strcmp(lower(a),'search')
        
        Speaker.Speak ('what should I search');
        
        %%hear what is being said
        hear();
        pause(5);
        
        fid = fopen('savetext.txt', 'r');
        name = fscanf(fid,'%c',inf);
%       name=fgets(fid);
        fclose(fid);
        
        imname=strcat(lower(name),'.png');
        if exist(imname)==0
           Speaker.Speak ('not in my database. give me the opportunity to learn');
        
        else
            data1 = imread(imname);
            data2 = getsnapshot(vid);
            stoppreview(vid);

            figure
            imshow(data2)

            xy_old=640;%depending on camera resolution

            eps1=0.05;
            eps2=5;

            valid=0;
            scale=0; %may be fixed from trial and error
            angle=90;

            while(~(scale>=1-eps1 || scale<=1+eps1)|| valid==0)
                [flag, xy_new]=matching(data1,data2);
                if (xy_new-xy_old>0)
                    fprintf('put your head down');
                    serial_send('b');
                end

                if flag==0
                    [valid,scale,angle]=scale_angle(data1,data2)
                    if valid==0
                        fprintf('rotate the head, scaling and angle not valid')
                        serial_send('a');
                    end

                else
                    d1=deblur2(data1);
                    d2=deblur2(data2);
                    [flag, xy_new]=matching(d1,d2);

                    if (xy_new-xy_old>0)
                        fprintf('put your head down'); 
                        serial_send('b');
                    end

                    if flag==1
                        fprintf('rotate the head')
                        serial_send('a');

                    else

                     [valid,scale,angle]=scale_angle(d1,d2)
                        if valid==0
                            fprintf('rotate the head, scaling and angle not valid')
                            serial_send('a');                    
                        else
                            serial_send('m');

                        end
                    end

                end
                    xy_old=xy_new;
                    pause(5);
                    data2 = getsnapshot(vid);
            end

            d=NaN;
            binfact=0.16;
            threshold=300;

            eps3=0.1;%grabbable distance

            while d~=eps3
                %laser part. after ensuring that laser has to fall on the object, move
                %the hand
                data = getsnapshot(vid);
                d=laser_track(data,binfact,threshold);

                if d~=NaN
                    serial_send('h');
                end

            end


            %%grabbing
            %at scale 1, distance is fixed, original size of object is proportional to
            %its size in image. proportionality constant will be found from trial and
            %error.

            sc_cons=1; %from callibration
            h=h*sc_cons;
            v=v*sc_cons;
            grab_length=h*cos(abs(angle))+v*sin(abs(angle));

            serial_send('g'); %enter grab mode
            serial_send(grab_length); %grab length for grab mode

            %% manage grab using grab_length

        end
    else
        %%%get the answer
        getans(text);   
    end
end

fclose(sr);
delete(sr);
clear sr

