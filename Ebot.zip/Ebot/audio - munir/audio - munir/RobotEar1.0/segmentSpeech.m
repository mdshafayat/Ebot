%%%%%<- written by Munir(0706043)->%%%%%

% [y1 Fs]= wavread('ek.wav');
y = filter([1 -0.97],1,y1);
figure,subplot(211),plot(y);
outline = zeros(1,length(y));
data = zeros(1,length(y));
windowSample = 160;
intervalSample = 80;
nframes = (length(y) - intervalSample)/(windowSample - intervalSample);

noise = 1:50;
sig = y(noise);
Var = var(sig);
Mean = mean(sig);
alpha = 0.2*Mean^-0.8;
TOL =(Var + alpha*Mean);
Sc = 1000;
activityFrame = 15;
falg = 0;
startFrame = 0;
endFrame = 0;

for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    sig = y(u:u+windowSample-1);
    E = sum(sig.*sig);
    P = E/length(sig);
    Sign = sign(sig);
    temp = [Sign(2:end);0];
    change = Sign - temp;
    Z = (sum(abs(change)/2))/length(sig);
    W = P*(1 - Z)*Sc;
    
    if W > TOL
        flag = flag+1;
        outline(u:u+windowSample-1) = 1;
    else
        if flag > activityFrame
            start = startFrame*windowSample - startFrame*intervalSample + 1;
            endf = (i-2)*windowSample - (i-2)*intervalSample + windowSample;
            data(start:endf) = y1(start:endf);
        end
        flag = 0;
        startFrame = i;
    end
end
hold on,plot(outline,'r');hold off
subplot(212),plot(data);