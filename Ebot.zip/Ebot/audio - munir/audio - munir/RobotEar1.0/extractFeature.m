function [MFCC Elog] = extractFeature(y,Fs,nfft,windowSample,intervalSample,K,Q)

%%%%%<- written by Munir(0706043)->%%%%%

% takes audio input and segments it into frames using overlapping window
% then it calculates MFCC  for each frame
Alldata = []; Elog = [];


speechSample = length(y);
%<- seglength*n - (n-1)*overlap = speechlength; ->%
nframes = (speechSample-intervalSample)/(windowSample - intervalSample);
for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    Alldata = [Alldata y(u:u+windowSample-1)];
    Elog = [Elog log10(sum(y(u:u+windowSample-1).^2))];
end

for i = 1:nframes
    % pre emphsising and windowing is done in mfcc.m
    MFCC(:,i) = mfcc(Alldata(:,i),Fs,nfft,K,Q);
end
