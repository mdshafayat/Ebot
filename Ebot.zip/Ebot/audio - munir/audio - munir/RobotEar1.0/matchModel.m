function mostLikely = matchModel(featureVector,numOfWords)
load MODELSalpha.mat

nll = zeros(numOfWords,1);
for nll_idx = 1:numOfWords
    [junk,nll(nll_idx)] = ...
    posterior(models(nll_idx).gmm,featureVector');
end

[nll_VAL,nll_IDX] = min(nll);
mostLikely = models(nll_IDX).word;