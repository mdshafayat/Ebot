
function MFSC = mfsc(y,Fs,nfft,K)

%%%%%<- written by Munir(0706043)->%%%%%

% Calculate Mel Frequency Spectral Coefficient
% Referrence : 
% An Introduction to Speech Recognition
%                B. Plannerer
%               March 28, 2005

W = makeW(Fs,K,nfft);
V = fft(y,nfft);
PV = abs(V); % the whole nfft size from malcom slaney
% PV = V.*conj(V); 
% PV = PV(1:nfft/2+1);
% % PV = pyulear(y,12,nfft,Fs); % <--- yule-walker PSD was tried instead of FFT

MFSC = W*PV;
