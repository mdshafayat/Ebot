clc;
clear all;
close all;

a=1;
while(a<100)
%%hear what is being said
hear();

%%%get the speech
fid = fopen('savetext.txt');
text=fgets(fid)
fclose(fid);

%%%get the answer
getans(text);

pause(2);
a=a+1;
end