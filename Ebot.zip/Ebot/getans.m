function []=getans(txt)%%for general Question Answer
%%%%%%%Manage input from text file
txt=lower(txt);
w = regexp(txt, '\s', 'split');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%load key from list
keylist='who what how you your me are can love name good morning noon evening afternoon night hello meet nice sing dance daddy like old do my song';
key = regexp(keylist, '\s', 'split');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%do key matching
j=1;
indx=0;
for i=1:length(key)
    a=strcmp(w,key(i));
    if (sum(a)~=0)
        indx(j)=i;
        j=j+1;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%get the answer%%%if 

if (sum((indx==3) | (indx==24))==2) %%how old are you? %Key: how old
    r=randi(4,1,1);
    
    switch r
        case 1
            tts('I am 18');
        case 2
            tts('I am at my forties');
        case 3
            tts('I just born');
        case 4
            tts('you have no business knowing that');
    end

elseif (sum((indx==3) | (indx==7) |(indx==4))==3) %%how are you? %Key: how are you
    r=randi(6,1,1);
    switch r
        case 1
            tts('I am fine');
        case 2
            tts('I am tired');
        case 3
            tts('I feel sick');
        case 4
            tts('I am bit confused');
        case 5
            tts('I am alive');
        case 6
            tts('I am happy');
    end
    tts('and how are you?');

elseif (sum((indx==2) | (indx==4) |(indx==7))==3) %%what are you? %Key: what are you
    r=randi(2,1,1);
    switch r
        case 1
            tts('I am a robot');
        case 2
            tts('I dont know');
    end    

elseif (sum((indx==6) | (indx==23))==2) %%Do you like me? %Key: like me
    r=randi(4,1,1);
    switch r
        case 1
            tts('I hate you');
        case 2
            tts('I dont know');
        case 3
            tts('who wants to know');
        case 4
            tts('I like you');
    end
    
elseif (sum((indx==8) | (indx==25))==2) %%What can you do? %Key: can do
    r=randi(3,1,1);
    switch r
        case 1
            tts('I can talk');
        case 2
            tts('I can walk');
        case 3
            tts('I can do any thing');
    end    

elseif (sum((indx==5) | (indx==10))==2) %%What is your name? %Key: your name
    r=randi(3,1,1);
    switch r
        case 1
            tts('My name is wall-e');
        case 2
            tts('wall-e');
        case 3
            tts('I am wall-e');
    end
    tts('what is your name?');

elseif (sum((indx==1) | (indx==7) |(indx==4))==3) %%who are you? %Key: how are you
     r=randi(3,1,1);
    switch r
        case 1
            tts('My name is wall-e');
        case 2
            tts('wall-e');
        case 3
            tts('I am wall-e');
    end
    
elseif (sum((indx==9))==1) %%Do you love me? %Key: love
    r=randi(3,1,1);
    switch r
        case 1
            tts('I love you');
        case 2
            tts('I love Rafi');
        case 3
            tts('Love, What is it?');
    end    
    
elseif (sum((indx==22))==1) %%who is your daddy? %Key: daddy
    r=randi(2,1,1);
    switch r
        case 1
            tts('I guess its not you');
        case 2
            tts('Rafi  Rafi');
    end    
    
elseif (sum((indx==20)|(indx==27))==1) %%Can you sing? %Key: sing or song
    r=randi(3,1,1);
    switch r
        case 1
            sound(wavread('song1.wav'),44000);
            pause(8);
        case 2
            sound(wavread('song2.wav'),44000);
            pause(8);
        case 3
            sound(wavread('song3.wav'),44000);
            pause(8);
        case 4
            tts('Sorry, I am not in the mode.');    
    end
    
elseif (sum((indx==21))==1) %%Can you dance? %Key: dance
    r=randi(3,1,1);
    switch r
        case 1
            tts('I cant dance');
        case 2
            tts('I am too old to dance!');
        case 3
            tts('Sorry, I am not in the mode.');
    end

elseif (sum((indx==26)|(indx==10))==2) %%My name is X? %Key: my name
    r=randi(2,1,1);
    switch r
        case 1
            tts('Nice to meet you');
        case 2
            tts('Nice name');
    end    
%     tts(char(w(find(strcmp(w,'is'))+1)))

elseif (sum((indx==12))==1) %%good morning
    r=randi(2,1,1);
    switch r
        case 1
            tts('Good Morning');
        case 2
            tts('Same to you.');
    end
 
elseif (sum((indx==13))==1) %%good noon
    r=randi(2,1,1);
    switch r
        case 1
            tts('Good noon');
        case 2
            tts('Same to you.');
    end    

elseif (sum((indx==14))==1) %%good evening
    r=randi(2,1,1);
    switch r
        case 1
            tts('Good Evening');
        case 2
            tts('Same to you.');
    end
    
elseif (sum((indx==15))==1) %%good afternoon
    r=randi(2,1,1);
    switch r
        case 1
            tts('Good Afternoon');
        case 2
            tts('Same to you.');
    end   
    
elseif (sum((indx==16))==1) %%good night
    r=randi(2,1,1);
    switch r
        case 1
            tts('Good night');
        case 2
            tts('Same to you.');
    end    
    
elseif (sum((indx==17))==1) %%hello
    r=randi(2,1,1);
    switch r
        case 1
            tts('Hello');
        case 2
            tts('Hi');
    end

elseif (sum((indx==18)|(indx==19))==2) %%nice to meet you key:nice meet
    r=randi(2,1,1);
    switch r
        case 1
            tts('Nice to meet you too');
        case 2
            tts('Same to you.');
    end
       
else %%when ans not known
    r=randi(9,1,1);
    switch r
        case 1
            tts('What are you talking about?');
        case 2
            tts('I dont understand.');
        case 3
            tts('Seriously?');
        case 4
            tts('Who would say that?');
        case 5
            tts('Can you repeat that?');
        case 6
            tts('You want me to say that ?');
        case 7
            tts('Sorry, I am not in the mode.');
        case 8
            tts('Sorry, cant hear you.');
        case 9
            tts('Dont want to talk now');
    end
  
end
    
