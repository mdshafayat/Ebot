
function ims(data1,name)
%check and save to database

imname=strcat(name,'.png');
figure
imshow(data1)

if exist (imname)==0
    imwrite(data1,imname, 'png')
end
